#pragma once
#include "Enemy.h"
#include "Player.h"
#include "Character.h"

void strike(Enemy*);

void defend(Player*);

void attack(Player*);

void weaken(Player*);
