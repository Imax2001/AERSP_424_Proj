Slay the Spire clone:

To run the Program, extract the zip file to an empty folder in a known location. Then, open the Microsoft Visual Studio 
application. Navigate to the file tab at the top of the page. Select the tab and then in the drop-down select open. After you select open
then select folder. Navigate to the folder you extracted the file to. Visual Studio will prompt you to clone the repository and select
"Clone." When the project opens up click on the file named "AERSP_424_Proj" right-click the tab then click "Set Project as Startup."
 

The program will start by making you click enter to enter a battle. The gameplay will look like a card game.
The player draws five cards of those cards there are two types of cards. A strike and a defend card a strike card
takes health points (HP) from the enemy. likewise, a defend reduces the damage taken by the player from the enemy's
attack. Do not let your HP go to zero, if you do you lose. 